package com.bignerdranch.android.books

import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    lateinit var button: Button
    var open:String="next"
    lateinit var textedit: EditText
    lateinit var x:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button = findViewById(R.id.find)
        x=getSharedPreferences("one", MODE_PRIVATE)
        textedit = findViewById(R.id.textfind)
        button.setOnClickListener {
            if(textedit.toString()!="")
            {
                x.edit()
                var intent=Intent(this, watchbook()::class.java)
                startActivity(intent)
            }
        }
    }
}
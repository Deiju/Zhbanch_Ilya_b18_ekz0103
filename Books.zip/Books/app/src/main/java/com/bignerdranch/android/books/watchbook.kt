package com.bignerdranch.android.books

import android.content.SharedPreferences
import android.media.Image
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class watchbook : AppCompatActivity() {
    lateinit var image: Image
    lateinit var name:TextView
    lateinit var author:TextView
    lateinit var x:SharedPreferences
    var open:String="next"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_watchbook)

    }
}